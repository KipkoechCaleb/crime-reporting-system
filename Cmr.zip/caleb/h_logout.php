<?php

session_start();
header("location:headlogin.php");
session_destroy();

?>